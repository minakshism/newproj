sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"sap/ui/core/EventBus",
	"sap/ui/core/Fragment",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (Controller, MessageToast, MessageBox, EventBus, formatter, Fragment, Filter, FilterOperator) {
	"use strict";
	const batchGroupId = "myUpdateGroupId";
	var geography;
	var ObjectPageLayout;
	var state;
	var oModel;
	var oView;
	var Router;
	var oView;

	return Controller.extend("nv.productMaster.controller.Detail", {
		onInit: function (Controller, MessageToast, MessageBox, EventBus, Fragment) {
			const router = this.getOwnerComponent().getRouter();
			const route = router.getRoute("Detail");
			oModel = this.getOwnerComponent().getModel();
			oView = this.getView();
			route.attachPatternMatched(this.onPatternMatched, this);
			route.attachBeforeMatched(this.reset, this);
			Router = this.getOwnerComponent().getRouter();

		},
		onPatternMatched: function (oEvt) {
			//this.bindSelectedItem(event.getParameter("arguments"));
			var id = oEvt.getParameter("arguments").id;
			this.getView().bindElement({
				path: `/ProductSystems(${id})`,
				parameters: {
					$$updateGroupId: batchGroupId
				}
			});

		},
		onBack: function (oEvt) {
			Router.navTo("Home");
		},
		resetEditingStatus: function () {
			const model = this.getOwnerComponent().getModel("detailViewModel");
			model.setProperty("/editing", false, null, true);
		},
		reset: function (event) {
			oModel.resetChanges(batchGroupId);
			this.resetEditingStatus();
		},
		

		
	
		onSubmitPress: async function (oEvent) {
			var sPath = this.getView().getBindingContext().getPath();
			var oProduct = this.getView().getBindingContext().getObject();
			if (this.getOwnerComponent().getModel().hasPendingChanges()) {
					this.byId("ObjectPageLayout").setBusy(true);
					await this.submitBatch(batchGroupId);
					this.byId("ObjectPageLayout").setBusy(false);
				
			}
			/*this.getOwnerComponent().getModel("v2").update(sPath, oProduct, {
					success: function(data){
						console.log("success");
						console.log(data);
					},
					error: function(data){
						console.log(data);
					}
				});
				*/

		/*	this._updateProduct(sPath, oProduct)
				.then(function () {
					MessageToast.show("Success...");
				})
				.catch(function (oError) {
					//Error handling...
					if (oError === "412") {
						this._openDialog();
					}
				});
				
		*/		

		},	submitBatch: async function (id) {
				return await oModel.submitBatch(id).then(
					function () {
						if (!oModel.hasPendingChanges()) {
							window.requestAnimationFrame(() => MessageToast.show("Product Updated"));
						}
					},
					function (oError) {
					}
				);
			},

		_updateProduct: function (sPath, oProduct, bForceUpdate) {
			debugger;
			var oDataModel = this.getView().getModel();
			return new Promise(function (resolve, reject) { 
				oDataModel.update(sPath, oProduct, {
					success: resolve,
					error: reject
				});
			});
		},
		_openDialog: function () {
			var that = this;
			var dialog = new Dialog({
				title: 'Confirm',
				type: 'Message',
				content: new Text({
					text: 'There is a more recent version available. Do you want to refresh or overwrite the backend entry?'
				}),
				beginButton: new Button({
					text: 'Overwrite',
					press: function () {
						that._update(true);
						dialog.close();
					}
				}),
				endButton: new Button({
					text: 'Refresh',
					press: function () {
						//Refresh entity....
						dialog.close();
					}
				}),
				afterClose: function () {
					dialog.destroy();
				}
			});
			dialog.open();
		},
		_update: function (bForceUpdate) {
			var that = this;
			var sPath = that.getView().getBindingContext().getPath();
			var oModel = that.getView().getModel();
			var oProduct = that.getView().getBindingContext().getObject();

			this._updateProduct(sPath, oProduct, bForceUpdate)
				.then(function () {
					MessageToast.show("Success...");
				})
				.catch(function (oError) {
					// Error handling
					//open Dialog if Precondition failed
					if (oError === "412") {
						this._openDialog();
					}
				});
		},

		_updateProduct: function (sPath, oProduct, bForceUpdate) {
			var oDataModel = this.getView().getModel();
			var oPromise = new Promise(function (resolve, reject) {
				var mParameters = {
					success: resolve,
					error: function (oError) {
						reject(oError.statusCode);
					}
				};
				if (bForceUpdate) {
					mParameters.eTag = "*";
				}

				oDataModel.update(sPath, oProduct, mParameters);
			});
			return oPromise;
		}

	});
});