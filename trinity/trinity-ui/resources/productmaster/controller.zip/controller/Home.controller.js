sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"sap/ui/core/EventBus",
	"sap/ui/core/Fragment"
], function (Controller, MessageToast, MessageBox, EventBus, Fragment) {
	"use strict";
	var Router;
	var oView;

	return Controller.extend("nv.productMaster.controller.Home", {
		onInit: function () {
			Router = this.getOwnerComponent().getRouter();
			oView = this.getView();
			var oNewProductBtn = this.getView().byId("idBtnNew");

			$.ajax({
				url: "/trinity/api/UserScopes",
				type: "GET",
				success: function (data, textStatus, jqXHR) {
					this.getView().byId("idBtnNew").setVisible(data.value[0].is_trinityadmin);
				}.bind(this),
				error: function (jqXHR, textStatus, errorThrown) {
				}.bind(this)
			});
		},
		navToDetailOf: function (item) {
			const id = item.getBindingContext().getProperty("id");
			Router.navTo("Detail", {
				id
			});
		},
		navToLogout: function (item) {
			window.location.replace("/my/logout");
		},
		newProduct: function (oEvent) {

			var oView = this.getView();

			if (!this._newProductDialog) {
				this._newProductDialog = Fragment.load({
					id: oView.getId(),
					name: "nv.productMaster.view.newProduct",
					controller: this
				}).then(function (oDialog) {
					oView.addDependent(oDialog);
					return oDialog;
				});
			}
			this._newProductDialog.then(function (oDialog) {
				oDialog.open();
			});

		},
			onConfirmProductDialog: function (oEvent) {
			this._newProductDialog.then(function (oDialog) {
				oDialog.close();
			});
			var oContext = this.getView().byId("masterList").getBinding("items")

			.create({
				"sys_model_no": oView.byId("sys_model_no").getValue(),
				"sys_model_description": oView.byId("sys_model_description").getSelectedKey()
			});
			oContext.created().then(
				function () {
					oView.byId("sys_model_no").setValue('');
					oView.byId("sys_model_description").setSelectedKey('');
					window.requestAnimationFrame(() => MessageToast.show("Product Created"));
				/*	const PartnerId = oContext.getProperty('id');
					Router.navTo("masterDetail", {
						PartnerId
					});
				*/
				},
				function (oError) {
					window.requestAnimationFrame(() => MessageToast.show("Product Creation Failed"));
				}
			);
		},
		onRejectProductDialog: function (oEvent) {
			oView.byId("sys_model_no").setValue('');
			oView.byId("sys_model_description").setSelectedKey('');
			this._newProductDialog.then(function (oDialog) {
				oDialog.close();
			});
		}
	});
});